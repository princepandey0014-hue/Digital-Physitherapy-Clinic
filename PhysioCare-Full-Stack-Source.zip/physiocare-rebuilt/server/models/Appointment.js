const mongoose = require('mongoose');
const appointmentSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, minlength: 2, maxlength: 100 },
  email: { type: String, required: true, trim: true, lowercase: true, maxlength: 150 },
  phone: { type: String, required: true, trim: true, maxlength: 30 },
  service: { type: String, required: true, trim: true, maxlength: 100 },
  date: { type: String, default: '' },
  message: { type: String, default: '', maxlength: 1500 },
  status: { type: String, enum: ['pending', 'confirmed', 'cancelled'], default: 'pending' }
}, { timestamps: true });
module.exports = mongoose.model('Appointment', appointmentSchema);
