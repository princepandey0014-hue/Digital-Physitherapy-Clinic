const express = require('express');
const Appointment = require('../models/Appointment');
const router = express.Router();

router.post('/', async (req, res) => {
  try {
    const { name, email, phone, service, date = '', message = '' } = req.body || {};
    if (!name || name.trim().length < 2) return res.status(400).json({ message: 'Please enter your full name.' });
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ message: 'Please enter a valid email address.' });
    if (!phone || phone.trim().length < 7) return res.status(400).json({ message: 'Please enter a valid phone number.' });
    if (!service) return res.status(400).json({ message: 'Please select a service.' });
    const appointment = await Appointment.create({ name, email, phone, service, date, message });
    return res.status(201).json({ message: 'Appointment request received.', appointment: { id: appointment._id, name: appointment.name, service: appointment.service, status: appointment.status } });
  } catch (error) {
    console.error('Appointment create error:', error.message);
    return res.status(500).json({ message: 'Could not save appointment. Please try again.' });
  }
});

// Demo/admin endpoint only. Protect with authentication before production deployment.
router.get('/', async (_req, res) => {
  try { const items = await Appointment.find().sort({ createdAt: -1 }).limit(100); res.json(items); }
  catch (error) { res.status(500).json({ message: 'Could not load appointments.' }); }
});
module.exports = router;
