# PhysioCare — Full-stack rebuild

A fresh, original recreation inspired by a physiotherapy clinic website, not the original site's recovered source code. React + Vite frontend, Express API, MongoDB/Mongoose appointment storage.

## Features
- Responsive clinic landing page, services, therapist cards, reviews and contact section
- Appointment request form with client-side validation
- Express REST API and MongoDB persistence
- Health-check endpoint and clear API error messages

## Requirements
Node.js 18+ and MongoDB Community Server (or a MongoDB Atlas connection string).

## Run on Windows / VS Code
1. Extract the ZIP and open `physiocare-rebuilt` in VS Code.
2. Open a terminal and run `npm install`.
3. Run `npm run install:all`.
4. Copy `server/.env.example` to `server/.env` and set `MONGODB_URI`.
   - Local MongoDB example: `mongodb://127.0.0.1:27017/physiocare`
5. Start MongoDB, then run `npm run dev` from the project root.
6. Open `http://localhost:5173`.

Backend API runs on `http://localhost:5000`.
- `GET /api/health`
- `POST /api/appointments`
- `GET /api/appointments` (basic demo listing; add authentication before public production use)

## Notes
- Appointment submissions are stored in MongoDB only when the backend is connected and `MONGODB_URI` is valid.
- Therapist names, reviews and clinic details are demo content; replace them with verified business information.
- Before production deployment, add authentication/authorization, rate limiting, email/WhatsApp notification integration, privacy notice, and stricter validation. Do not expose the appointments listing endpoint publicly.
- The website URL provided in chat does not expose the original source code. This is a clean reimplementation with comparable clinic-site sections, not an exact source recovery.
